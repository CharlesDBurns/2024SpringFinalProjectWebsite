
function cloudlandMap() {
    var mapProp = {
        center: new google.maps.LatLng(34.8395, -85.4840),
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        zoom: 15
    };
    var parkMap;
    parkMap = new google.maps.Map(document.getElementById('map'), mapProp);
    var pinLocation = new google.maps.LatLng( 34.83668774115008, -85.4883706333269 );

    var firstPosition = new google.maps.Marker({
        map: parkMap,
        position: pinLocation,
        title: 'Cloudland State Park- Campsite #39'
    });
    var pinLocation = new google.maps.LatLng( 34.833905777611285, -85.48394903304559 );

    var secondPosition = new google.maps.Marker({
        map: parkMap,
        position: pinLocation,
        title: 'Cloudland Canyon- Cherokee Falls'
    });
    
    styles: [
    {
        stylers: [
            { hue: "#0091ff" },
            { saturation: 50 }
        ]
    }, {
        featureType: "road",
        elementType: "geometry",
        stylers: [
            { lightness: 30 },
            { visibility: "detailed" }
        ]
    }
]
};




