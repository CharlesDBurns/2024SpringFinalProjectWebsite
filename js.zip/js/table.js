
var parks = [
    {
        name: 'Bryce Canyon National Park',
        rating: 4.9
    },
    {
        name: 'Cloudland Canyon State Park',
        rating: 4.8
    },
    {
        name: 'Gates of the Artic National Park and Preserve',
        rating: 4.5
    },
    {
        name: 'Grand Teton National Park',
        rating: 4.9
    },
    {
        name: 'Grant Park',
        rating: 4.6
    },
    {
        name: 'Great Basin National Park',
        rating: 4.7
    },
    {
        name: 'Indiana Dunes National Park',
        rating: 4.6
    },
    {
        name: 'Kobuk Valley National Park',
        rating: 4.0
    },
    {
        name: 'Voyageurs National Park',
        rating: 4.8
    },
    {
        name: 'Wrangell-St. Elias National Park and Preserve',
        rating: 4.7
    },
    {
        name: 'Yellowstone National Park',
        rating: 4.8
    }
]

var $tableBody = $('<tbody></tbody>');
for (var i = 0; i < parks.length; i++) {
    var park = parks[i];
    var $row = $('<tr></tr>');
    $row.append($('<td></td>').text(park.name));
    $row.append($('<td></td>').text(park.rating));
    $tableBody.append( $row );
}

$('thead').after($tableBody);

